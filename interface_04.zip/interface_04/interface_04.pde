import processing.pdf.*;
import controlP5.*;

ControlP5 cp5;

Knob myKnobContador;

int knob_contador =20;
int slider_sc=75;

boolean record_pdf=false;

void setup() {
  size(500, 700);
  cp5 = new ControlP5(this);
  
  myKnobContador = cp5.addKnob("knob_contador")
    .setRange(2, 255)
    .setValue(50)
    .setPosition(10, 70)
    .setRadius(50)
    .setDragDirection(Knob.VERTICAL)
    ;
    
  cp5.addBang("guarda_pdf")
    .setPosition(10, 200)
    .setSize(100, 40)
    .setTriggerEvent(Bang.RELEASE)
    .setLabel("PDF")
    ;
    
  cp5.addBang("guarda_png")
    .setPosition(10, 270)
    .setSize(100, 40)
    .setTriggerEvent(Bang.RELEASE)
    .setLabel("PNG")
    ;
}

void draw() {
  if(record_pdf == true){
    beginRecord(PDF, "cercles-####.pdf");
  }
  background(255);
  fill(0);
  for (int i=0; i<knob_contador; i++) {
    push();
    translate(random(slider_sc, width-slider_sc), random(slider_sc, height-slider_sc));
    ellipse(0, 0, slider_sc, slider_sc);
    pop();
  }
  if(record_pdf == true){
    endRecord();
    record_pdf=false;
  }
}

public void guarda_pdf(){
  record_pdf=true;
}
public void guarda_png(){
  save("cercles-"+frameCount+".png");
}
